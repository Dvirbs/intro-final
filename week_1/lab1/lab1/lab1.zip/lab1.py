########################################################################
# FILE : lab1.py
# WRITER: Dvir ,Dvirbs , 204270243
# EXERCISE : intro2cs1 lab1 2021
# DESCRIPTION: A simple program that prints "Hello World!" to
# the standard output(screen).
########################################################################
print("Hello World!")